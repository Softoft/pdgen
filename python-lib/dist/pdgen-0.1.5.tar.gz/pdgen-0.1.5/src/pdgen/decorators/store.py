from pdgen.decorators.uml_types import UMLClass

ALL_CLASSES: list[UMLClass] = []
