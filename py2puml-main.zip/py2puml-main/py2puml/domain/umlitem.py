from dataclasses import dataclass


@dataclass
class UmlItem:
    name: str
    fqn: str
