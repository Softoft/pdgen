from dataclasses import dataclass


@dataclass
class Roots:
    mass: float
