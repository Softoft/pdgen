from dataclasses import dataclass


@dataclass
class Soil:
    humidity: float
