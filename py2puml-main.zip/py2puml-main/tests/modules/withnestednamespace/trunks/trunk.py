from dataclasses import dataclass


@dataclass
class Trunk:
    height: float
