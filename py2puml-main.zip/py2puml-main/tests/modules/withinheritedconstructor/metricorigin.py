from .point import Origin


class MetricOrigin(Origin):
    unit: str = 'm'
