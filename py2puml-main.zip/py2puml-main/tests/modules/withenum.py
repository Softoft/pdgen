from enum import Enum


class TimeUnit(Enum):
    DAYS = 'd'
    HOURS = 'h'
    MINUTE = 'm'
