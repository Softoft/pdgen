module.exports = {
    extends: [
        '@commitlint/config-angular'
    ],
    rules: {
        'header-max-length': [2, 'always', 120],
    }
}
